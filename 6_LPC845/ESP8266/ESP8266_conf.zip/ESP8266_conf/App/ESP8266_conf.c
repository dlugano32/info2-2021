#include "DR_Init.h"
#include "PR_UART.h"
#include "ESP8266App.h"

uint8_t mensaje[] = "RECIBIDO:";

int main(void)
{
	//int16_t msg=-1;

	InitHw();

	LED_OFF(ROJO);
	LED_OFF(VERDE);
	LED_OFF(AZUL);

	//TxSerie0((uint8_t *)"AT\r\n");

    while(1)
    {
    	/*
    	msg=RxSerie0();

    	if(msg!=-1)
    	{
    		LED_ON(ROJO);
    		TxSerie0(mensaje);
    		Tx0Byte(msg);
    	}
    	*/
    	ESP8266Mde();
    	TimerEvent();
    }
    return 0 ;
}
